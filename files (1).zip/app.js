/* ================================================
   GEM SYSTEMS — app.js
   Lógica principal da aplicação
   ================================================ */

// *** 1. CLIMA ***
const API_KEY   = '';          // Insira sua chave OpenWeatherMap aqui
const LATITUDE  = -26.9079;
const LONGITUDE = -48.6659;

async function buscarClima() {
    if (!API_KEY) return;
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${LATITUDE}&lon=${LONGITUDE}&appid=${API_KEY}&units=metric&lang=pt_br`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        if (response.ok) {
            const temperatura = Math.round(data.main.temp);
            const descricao   = data.weather[0].description;
            console.log(`Clima: ${temperatura}° - ${descricao}`);
        }
    } catch (error) {
        console.error('Erro clima:', error);
    }
}

// *** 2. RELÓGIO ***
function atualizarRelogioEData() {
    const agora    = new Date();
    const horas    = String(agora.getHours()).padStart(2, '0');
    const minutos  = String(agora.getMinutes()).padStart(2, '0');
    const segundos = String(agora.getSeconds()).padStart(2, '0');
    document.getElementById('relogio-widget').textContent = `${horas}:${minutos}:${segundos}`;
}

// *** 3. ID DE SESSÃO ***
let uniqueSessionID = null;

function generateUniqueCode() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
        uniqueSessionID = crypto.randomUUID();
    } else {
        uniqueSessionID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
    document.getElementById('session-display').textContent = uniqueSessionID;
    return uniqueSessionID;
}

// *** 4. CALENDÁRIO ***
let currentCalendarDate = new Date();
let calendarNotes = {};

function formatDateToKey(date) {
    const year  = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day   = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function loadNotesFromLocalStorage() {
    const storedNotes = localStorage.getItem('calendarNotes');
    try   { calendarNotes = storedNotes ? JSON.parse(storedNotes) : {}; }
    catch { calendarNotes = {}; }
}

function saveNotesToLocalStorage() {
    localStorage.setItem('calendarNotes', JSON.stringify(calendarNotes));
}

function renderCalendar() {
    const grid             = document.getElementById('calendar-grid');
    const monthYearDisplay = document.getElementById('current-month-year');
    grid.innerHTML = '';
    loadNotesFromLocalStorage();

    const viewYear  = currentCalendarDate.getFullYear();
    const viewMonth = currentCalendarDate.getMonth();
    const today     = new Date();
    const isTodayMonth = today.getFullYear() === viewYear && today.getMonth() === viewMonth;
    const todayDay     = today.getDate();

    const monthNames = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
    monthYearDisplay.textContent = `${monthNames[viewMonth]} ${viewYear}`;

    const firstDayOfMonth = new Date(viewYear, viewMonth, 1).getDay();
    const daysInMonth     = new Date(viewYear, viewMonth + 1, 0).getDate();

    for (let i = 0; i < firstDayOfMonth; i++) {
        const cell = document.createElement('div');
        cell.classList.add('day', 'empty', 'other-month');
        grid.appendChild(cell);
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const date    = new Date(viewYear, viewMonth, day);
        const dateKey = formatDateToKey(date);
        const cell    = document.createElement('div');
        cell.classList.add('day');
        cell.textContent = day;
        cell.setAttribute('data-full-date', dateKey);

        if (isTodayMonth && day === todayDay) {
            cell.classList.add('current-day');
        } else {
            cell.classList.add('text-white', 'hover:bg-cyan-600/50');
        }

        const noteContent = calendarNotes[dateKey];
        if (noteContent) {
            cell.classList.add('has-note');
            cell.setAttribute('title', `Nota: ${noteContent}`);
        } else {
            cell.setAttribute('title', 'Clique para adicionar nota.');
        }

        cell.addEventListener('click', handleDayClick);
        grid.appendChild(cell);
    }

    const totalCells     = firstDayOfMonth + daysInMonth;
    const requiredRows   = Math.ceil(totalCells / 7);
    const remainingCells = requiredRows * 7 - totalCells;
    for (let i = 0; i < remainingCells; i++) {
        const cell = document.createElement('div');
        cell.classList.add('day', 'empty', 'other-month');
        grid.appendChild(cell);
    }
}

function changeMonth(direction) {
    currentCalendarDate.setMonth(currentCalendarDate.getMonth() + direction);
    renderCalendar();
}

function handleDayClick(event) {
    const cell    = event.currentTarget;
    if (cell.classList.contains('empty')) return;

    const dateKey      = cell.getAttribute('data-full-date');
    const existingNote = calendarNotes[dateKey] || '';
    const friendlyDate = new Date(dateKey + 'T00:00:00').toLocaleDateString('pt-BR', {
        weekday: 'short', day: 'numeric', month: 'short'
    });

    const promptMessage = existingNote
        ? `NOTA (${friendlyDate}):\n${existingNote}\n\n[OK p/ Editar | Limpe p/ Excluir]`
        : `NOVA NOTA para ${friendlyDate}:`;

    const userNote = prompt(promptMessage, existingNote);
    if (userNote !== null) {
        const trimmedNote = userNote.trim();
        if (trimmedNote === '') {
            delete calendarNotes[dateKey];
        } else {
            calendarNotes[dateKey] = trimmedNote;
            const compartilhar = confirm(`✅ Nota salva!\n\nDeseja compartilhar no WhatsApp?\n\n📅 ${friendlyDate}\n📝 ${trimmedNote}`);
            if (compartilhar) {
                const texto = encodeURIComponent(`📅 *${friendlyDate}*\n📝 ${trimmedNote}`);
                window.open(`https://wa.me/?text=${texto}`, '_blank');
            }
        }
        saveNotesToLocalStorage();
        renderCalendar();
    }
}

// *** 5. TABELA DE CARGAS ***
const dadosSimuladosCargas = [
    { bl: 'BRSS-871', prazo: '06/11', status: 'Pronto',   cssClass: 'status-pronto'   },
    { bl: 'BRSS-872', prazo: '06/11', status: 'Atraso',   cssClass: 'status-atraso'   },
    { bl: 'BRSS-873', prazo: '07/11', status: 'Pendente', cssClass: 'status-pendente' },
    { bl: 'BRSS-874', prazo: '07/11', status: 'Pronto',   cssClass: 'status-pronto'   },
    { bl: 'BRSS-875', prazo: '08/11', status: 'Pendente', cssClass: 'status-pendente' },
    { bl: 'BRSS-876', prazo: '08/11', status: 'Pronto',   cssClass: 'status-pronto'   },
    { bl: 'BRSS-877', prazo: '09/11', status: 'Pendente', cssClass: 'status-pendente' },
    { bl: 'BRSS-878', prazo: '09/11', status: 'Pronto',   cssClass: 'status-pronto'   },
];

function renderTabelaCargas() {
    const tbody = document.getElementById('tabela-cargas-body');
    tbody.innerHTML = '';
    dadosSimuladosCargas.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="font-mono text-xs">${item.bl}</td>
            <td class="text-xs">${item.prazo}</td>
            <td class="${item.cssClass} text-xs">${item.status}</td>
        `;
        tbody.appendChild(row);
    });
}

// *** 6. KPIs ***
const dadosKPIs = [
    { id: 'total-processos', label: 'Proc. Dia', value: 85, unit: 'un', cssClass: 'kpi-success' },
    { id: 'em-atraso',       label: 'Atraso',    value:  3, unit: 'un', cssClass: 'kpi-danger'  },
    { id: 'pronto-embarque', label: 'Pronto',    value: 92, unit: '%',  cssClass: 'kpi-success' },
    { id: 'aguardando-docs', label: 'Docs',      value: 12, unit: 'un', cssClass: 'kpi-warning' },
];

function renderKPIs() {
    const kpiGrid = document.getElementById('kpi-grid');
    kpiGrid.innerHTML = '';
    dadosKPIs.forEach(kpi => {
        const card = document.createElement('div');
        card.id = kpi.id;
        card.classList.add('kpi-card', kpi.cssClass);
        const displayValue = kpi.unit === '%' ? `${kpi.value}%` : kpi.value;
        card.innerHTML = `
            <div class="value">${displayValue}</div>
            <div class="label" style="font-size:0.65rem;">${kpi.label}</div>
        `;
        kpiGrid.appendChild(card);
    });
}

// *** 7. NOTAS RÁPIDAS ***
let savedNoteContent = localStorage.getItem('quickNote') || '';

function loadQuickNote() {
    document.getElementById('quick-note-text').value = savedNoteContent;
}

function saveQuickNote() {
    const noteTextarea = document.getElementById('quick-note-text');
    const noteStatus   = document.getElementById('note-status');
    const content      = noteTextarea.value.trim();

    if (content === '') {
        noteStatus.textContent = 'Nota vazia.';
        noteStatus.style.color = '#f87171';
        return;
    }

    savedNoteContent = content;
    localStorage.setItem('quickNote', content);
    noteStatus.textContent = 'Salvo!';
    noteStatus.style.color = '#a3e635';
    setTimeout(() => { noteStatus.textContent = ''; }, 3000);
}

// *** 8. ROBÔ / ARKANOID ***
const greetings = [
    "Sistema ZIM ativo.",
    "Olá! Precisa de ajuda?",
    "Conexão estável.",
    "IA pronta para uso.",
    "Processando dados...",
    "Tudo em ordem por aqui."
];

function showRandomGreeting() {
    const robotGreeting = document.getElementById('robot-greeting');
    robotGreeting.textContent = greetings[Math.floor(Math.random() * greetings.length)];
    robotGreeting.style.opacity = '1';
    setTimeout(() => { robotGreeting.style.opacity = '0'; }, 4000);
}

function toggleChatbot() {
    const arkanoid       = document.getElementById('arkanoid-widget');
    const robotContainer = document.getElementById('robot-container');
    const robotGreeting  = document.getElementById('robot-greeting');
    const jogoAberto     = arkanoid.style.display === 'block';

    if (!jogoAberto) {
        arkanoid.style.display             = 'block';
        robotContainer.style.opacity       = '0';
        robotContainer.style.pointerEvents = 'none';
        robotGreeting.style.opacity        = '0';
        initArkanoid();
    } else {
        arkanoid.style.display             = 'none';
        robotContainer.style.opacity       = '1';
        robotContainer.style.pointerEvents = 'auto';
        stopArkanoid();
    }
}

// *** 9. LEMBRETE ***
let lembreteHorario = null;
let lembreteAtivo   = false;

function definirLembrete() {
    const inputTime = document.getElementById('horarioLembrete').value;
    if (inputTime) {
        lembreteHorario = inputTime;
        lembreteAtivo   = true;
        document.getElementById('statusLembrete').innerText = `Alarme: ${lembreteHorario}`;
    }
}

function checarLembrete() {
    if (!lembreteAtivo || !lembreteHorario) return;
    const agora       = new Date();
    const horaAtual   = agora.getHours().toString().padStart(2, '0');
    const minutoAtual = agora.getMinutes().toString().padStart(2, '0');
    if (`${horaAtual}:${minutoAtual}` === lembreteHorario) {
        alert(`🚨 Lembrete: ${lembreteHorario}!`);
        lembreteAtivo = false;
        document.getElementById('statusLembrete').innerText = 'Disparado!';
    }
}

// *** 10. BACKEND PYTHON (teste) ***
async function chamarPython() {
    const nome = document.getElementById('nome').value;
    const res  = await fetch(`/api/elogio?nome=${nome}`);
    const data = await res.json();
    document.getElementById('resultado').innerText = `${data.mensagem} (${data.origem})`;
}

// *** 11. INICIALIZAÇÃO ***
window.onload = function () {
    generateUniqueCode();

    atualizarRelogioEData();
    setInterval(atualizarRelogioEData, 1000);

    loadNotesFromLocalStorage();
    renderCalendar();
    document.getElementById('prev-month').addEventListener('click', () => changeMonth(-1));
    document.getElementById('next-month').addEventListener('click', () => changeMonth(1));

    renderTabelaCargas();
    renderKPIs();
    loadQuickNote();

    document.getElementById('save-note-btn').addEventListener('click', saveQuickNote);

    document.getElementById('whatsapp-note-btn').addEventListener('click', function () {
        const content = document.getElementById('quick-note-text').value.trim();
        if (!content) { alert('Digite uma nota antes de enviar!'); return; }
        const texto = encodeURIComponent(`📝 *Nota Rápida - GEM Systems*\n\n${content}`);
        window.open(`https://wa.me/?text=${texto}`, '_blank');
    });

    buscarClima();
    setInterval(buscarClima, 600000);

    setTimeout(showRandomGreeting, 1700);
    setInterval(showRandomGreeting, 60000);

    setInterval(checarLembrete, 1000);

    document.getElementById('robot-container').addEventListener('click', toggleChatbot);
    document.getElementById('close-chat-btn').addEventListener('click', toggleChatbot);
};
